# pokemon_fire_red
A recreation of Pokemon Fire Red in python (moved directories, original code including all commit history can be found at https://github.com/arnab-sen/practice_projects/tree/master/python/battle_simulator)

Here's a look at it so far:

![Pokemon Pallet Town Recreation](https://i.imgur.com/qaqZJ7D.gif)